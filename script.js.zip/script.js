// SETUP VARIABLES
// ================================================================
    var apiKey = "c9871eecb074811b7872bedc2fda20f7";
    var city = '';
    var queryURLBase = "https://api.openweathermap.org/data/2.5/weather?&units=imperial&appid=" + apiKey;
    // `https://api.openweathermap.org/data/2.5/weather?&units=imperial&appid=${apiKey} &q=${city}`;

// Functions
// ================================================================
function runQuery(oneDay) {
    $.ajax({
        url: oneDay,
        method: "GET",
    }).then(function(weatherData) { 
        $('#cityButtons').empty();
        console.log(weatherData);
        console.log(oneDay);
    })
}    

function showCities() {
    $("#cityButtons").empty(); // empties out previous array 
    var arrayFromStorage = JSON.parse(localStorage.getItem("allCities")) || []; // Makes all cities searched a string
    var arrayLength = arrayFromStorage.length; // limits length of array
  
    for (var i = 0; i < arrayLength; i++) { // Loop so it prepends all cities within the length of the array
      var cityNameFromArray = arrayFromStorage[i]; //
  
      $("#cityButtons").append (
        //styling 
        "<div class='list-group'>"
    
      // City text
      + "<button class='list-group-item'>" + cityNameFromArray 
      + "</button>")
    } // end of loop 
  } // end of showCities function 
  
  showCities (); // calls function to append cities upon page load 
  
  // show cities on click 
  $("#cityButtons").on("click", function(event) {
    event.preventDefault();
   // showWeather(city); 
   showCities ();
  }) // end of ci

// MAIN PROCESS
// ================================================================

    $('#search').on('click', function (event) {
        event.preventDefault();

        var newURL = queryURLBase + "&q=" + city;
        city = $('#input').val().trim()
        var allCities = [];
        
        allCities = JSON.parse(localStorage.getItem("allCities")) || []; // Get cities
        allCities.push(city); // pushes new cities entered to array 
        localStorage.setItem("allCities", JSON.stringify(allCities)); //saves city input to local storage 

        // Add in the Search Term

        runQuery(newURL);
    });

    // activity 7

    